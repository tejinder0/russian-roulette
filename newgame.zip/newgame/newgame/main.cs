﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace newgame
{
    public partial class main : Form
    {
        // VARIABLES
        public int load, Spin, Score = 0, Win = 0, Loss = 0, Count = 0;

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 game = new Form1();
            game.Show();
            this.Close();
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.GetCurrentProcess().Kill();

            Application.Exit();
        }

        public main()
        {
            InitializeComponent();
        }
        private void btnspin_Click(object sender, EventArgs e)
        {

            pictureBox1.Visible = true; 
            Image img = Image.FromFile(@"C:\Users\PC.LAPTOP-G18I3MB0\Desktop\newgame\load.gif");
            pictureBox1.Image = img;
            
            //below code for spining the chamber and it will pick bullet randomly
            Random rnd = new Random();
            //below code helps to pick random number between 1-7.
            Spin = rnd.Next(1, 7); 

            btnshoot.Enabled = true;
            btnspin.Enabled = false;
        }

        private void btnshoot_Click(object sender, EventArgs e)
        {
            { //below code helps to show the picbox
                pictureBox1.Visible = true;
                //below code is for uploading the image
                Image img = Image.FromFile(@"C:\Users\PC.LAPTOP-G18I3MB0\Desktop\newgame\shoot.gif");
                pictureBox1.Image = img;
                // below code is for uploading the sound
                System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"C:\Users\PC.LAPTOP-G18I3MB0\Desktop\newgame\gun.wav");
                player.Play();
                if (Count < 2)
                {
                    if (Spin == load)
                    {
                        Win = Win + 1;
                        Score = Score + 10;
                        Spin = Spin + 1;
                        Count = 3;
                    }
                    else
                    {
                        Spiner s = new Spiner();
                        Spin = s.spiner(Spin);
                        Count = Count + 1;
                    }

                }
                else
                {
                    Loss = Loss + 1;
                    btnshoot.Enabled = false;

                }
                if (Count >= 2)
                { // below code is for pop up the message of win and loss.
                    if (Score != 0)
                    {
                        MessageBox.Show("WELL PLAYED YOU WON THE GAME \n KEEP PLAYING \n  RUSSIAN ROULLETE \n YOUR SCORE IS " + Score);
                    }
                    else
                    {
                        MessageBox.Show("BETTER LUCK NEXT TIME \n THE GAME OVER \n KEEP PLAYING RUSSIAN ROULLETE \n YOUR SCORE IS  " + Score);
                    }
                }


            }
        }

        private void btnload_Click(object sender, EventArgs e)
        {
            
            load = 1;

            btnspin.Enabled = true;
            btnload.Enabled = false;
        }

       

        private void main_Load(object sender, EventArgs e)
        {
            pictureBox1.Visible = false;
            btnspin.Enabled = false;
            btnshoot.Enabled = false;
            lblname.Text = Form1.name;
        }
    }
}
