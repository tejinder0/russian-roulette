﻿namespace newgame
{
    partial class main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(main));
            this.lblname = new System.Windows.Forms.Label();
            this.btnload = new System.Windows.Forms.Button();
            this.btnspin = new System.Windows.Forms.Button();
            this.btnshoot = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnexit = new System.Windows.Forms.Button();
            this.btntry = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.BackColor = System.Drawing.Color.Transparent;
            this.lblname.Font = new System.Drawing.Font("Impact", 28.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblname.Location = new System.Drawing.Point(604, 9);
            this.lblname.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(0, 46);
            this.lblname.TabIndex = 0;
            // 
            // btnload
            // 
            this.btnload.BackColor = System.Drawing.Color.Red;
            this.btnload.Font = new System.Drawing.Font("Impact", 28.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnload.Location = new System.Drawing.Point(12, 41);
            this.btnload.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btnload.Name = "btnload";
            this.btnload.Size = new System.Drawing.Size(104, 60);
            this.btnload.TabIndex = 1;
            this.btnload.Text = "LOAD";
            this.btnload.UseVisualStyleBackColor = false;
            this.btnload.Click += new System.EventHandler(this.btnload_Click);
            // 
            // btnspin
            // 
            this.btnspin.BackColor = System.Drawing.Color.Red;
            this.btnspin.Font = new System.Drawing.Font("Impact", 28.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnspin.Location = new System.Drawing.Point(12, 117);
            this.btnspin.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btnspin.Name = "btnspin";
            this.btnspin.Size = new System.Drawing.Size(116, 52);
            this.btnspin.TabIndex = 2;
            this.btnspin.Text = "SPIN";
            this.btnspin.UseVisualStyleBackColor = false;
            this.btnspin.Click += new System.EventHandler(this.btnspin_Click);
            // 
            // btnshoot
            // 
            this.btnshoot.BackColor = System.Drawing.Color.Red;
            this.btnshoot.Font = new System.Drawing.Font("Impact", 28.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnshoot.Location = new System.Drawing.Point(11, 186);
            this.btnshoot.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btnshoot.Name = "btnshoot";
            this.btnshoot.Size = new System.Drawing.Size(137, 56);
            this.btnshoot.TabIndex = 3;
            this.btnshoot.Text = "SHOOT";
            this.btnshoot.UseVisualStyleBackColor = false;
            this.btnshoot.Click += new System.EventHandler(this.btnshoot_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(452, 81);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(326, 250);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Impact", 28.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(373, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(205, 46);
            this.label1.TabIndex = 5;
            this.label1.Text = "YOUR NAME :";
            // 
            // btnexit
            // 
            this.btnexit.BackColor = System.Drawing.Color.Yellow;
            this.btnexit.Font = new System.Drawing.Font("Impact", 24.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnexit.Location = new System.Drawing.Point(282, 286);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(100, 46);
            this.btnexit.TabIndex = 6;
            this.btnexit.Text = "EXIT";
            this.btnexit.UseVisualStyleBackColor = false;
            this.btnexit.Click += new System.EventHandler(this.btnexit_Click);
            // 
            // btntry
            // 
            this.btntry.BackColor = System.Drawing.Color.Yellow;
            this.btntry.Font = new System.Drawing.Font("Impact", 16.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btntry.Location = new System.Drawing.Point(157, 285);
            this.btntry.Name = "btntry";
            this.btntry.Size = new System.Drawing.Size(115, 46);
            this.btntry.TabIndex = 7;
            this.btntry.Text = "TRY AGAIN";
            this.btntry.UseVisualStyleBackColor = false;
            this.btntry.Click += new System.EventHandler(this.button2_Click);
            // 
            // main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btntry);
            this.Controls.Add(this.btnexit);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnshoot);
            this.Controls.Add(this.btnspin);
            this.Controls.Add(this.btnload);
            this.Controls.Add(this.lblname);
            this.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.Name = "main";
            this.Text = "WELCOME TO RUSSIAN ROLLETE";
            this.TransparencyKey = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Load += new System.EventHandler(this.main_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.Button btnload;
        private System.Windows.Forms.Button btnspin;
        private System.Windows.Forms.Button btnshoot;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnexit;
        private System.Windows.Forms.Button btntry;
    }
}